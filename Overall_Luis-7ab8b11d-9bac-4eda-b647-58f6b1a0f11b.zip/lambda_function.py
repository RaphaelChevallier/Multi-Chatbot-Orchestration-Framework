from botocore.vendored import requests
import json

def lambda_handler(event, context):
    inputMessage = event["inputTranscript"]
    inputMinScore = event["minScore"]

    results = LUIS_Call(inputMessage)
    
    supportedConversation = False
    if results["topScoringIntent"]["score"] >= inputMinScore:
        supportedConversation = True
                
    output = {
        "query": inputMessage,
        "topScoringIntent": results["topScoringIntent"],
        "supportedConversation": supportedConversation
    }
    
    
    return {
        "sessionAttributes": {
            "query": inputMessage,
            "topScoringIntent": results["topScoringIntent"]["intent"],
            "topScoringScoreofIntent" : results["topScoringIntent"]["score"],
            "supportedConversation": supportedConversation
        },
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled"
        }
    }

#Call on LUIS app here
def LUIS_Call(message):
    headers = {
        # Request headers
        'Ocp-Apim-Subscription-Key': '653d36ad37d5460abd6f06b434447bc8',
    }

    params = {
        'q': message,
        'verbose': True
    }

    try:
        r = requests.get('https://southeastasia.api.cognitive.microsoft.com/luis/v2.0/apps/bdab96c5-84e5-4f6d-9a2f-8294a8ac30d6',headers=headers, params=params)
        return r.json()

    except Exception as e:
        print("[Errno {0}] {1}".format(e.errno, e.strerror))