import boto3
import json

def lambda_handler(event, context):
    responderName = event["DestinationBot"]
    userId = event["RecipientID"]
    userInput = event["text"]
    
    client = boto3.client('lex-runtime')
    
    response = client.post_text(
        botName=responderName,
        botAlias="Prod",
        userId=userId,
        sessionAttributes={
        },
        requestAttributes={
        },
        inputText = userInput
    )
    
    return response